package pl.sda.calculation2;

public class ExchangeRates {
    public String table;//nazwa waluty
    public String no;//kod waluty
    public String effctiveDate;
   public ExchangeSingleRate[]rates;


}
