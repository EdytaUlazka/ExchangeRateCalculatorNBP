package pl.sda.calculation2;

public class SellingRates {
    public String table;
    public String no;
    public String tradingDate;
    public String effectingDate;
    public SellingSingleRate[]rates;


}

