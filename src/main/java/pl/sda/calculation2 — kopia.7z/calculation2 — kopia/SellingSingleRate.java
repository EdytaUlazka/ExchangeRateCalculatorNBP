package pl.sda.calculation2;

public class SellingSingleRate {
    public String currency;
    public String code;
    public Double bid;
    public Double ask;
}
