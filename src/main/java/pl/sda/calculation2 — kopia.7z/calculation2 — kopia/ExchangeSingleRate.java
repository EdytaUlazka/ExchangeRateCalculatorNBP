package pl.sda.calculation2;

public class ExchangeSingleRate {
    public String currency;
    public String code;
    public Double mid;
}
